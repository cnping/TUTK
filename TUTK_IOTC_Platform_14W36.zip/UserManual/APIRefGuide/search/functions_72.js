var searchData=
[
  ['rdt_5fabort',['RDT_Abort',['../_r_d_t_a_p_is_8h.html#ae86b41a34237a86ac60f4bf55ae5b805',1,'RDTAPIs.h']]],
  ['rdt_5fcreate',['RDT_Create',['../_r_d_t_a_p_is_8h.html#aec099dec40b8276141437a8da57d2247',1,'RDTAPIs.h']]],
  ['rdt_5fcreate_5fexit',['RDT_Create_Exit',['../_r_d_t_a_p_is_8h.html#a31986241df6490707fc6c5fc02adce86',1,'RDTAPIs.h']]],
  ['rdt_5fdeinitialize',['RDT_DeInitialize',['../_r_d_t_a_p_is_8h.html#a39b0c14386a6b7c2c3b505f40919a4a6',1,'RDTAPIs.h']]],
  ['rdt_5fdestroy',['RDT_Destroy',['../_r_d_t_a_p_is_8h.html#af0a73a489a36665c6358927bdbe4a640',1,'RDTAPIs.h']]],
  ['rdt_5fgetrdtapiver',['RDT_GetRDTApiVer',['../_r_d_t_a_p_is_8h.html#a30cfeef555f61fd60491b4651a92b8cb',1,'RDTAPIs.h']]],
  ['rdt_5finitialize',['RDT_Initialize',['../_r_d_t_a_p_is_8h.html#a155df3b76daa9dca897cb7975290c325',1,'RDTAPIs.h']]],
  ['rdt_5fread',['RDT_Read',['../_r_d_t_a_p_is_8h.html#a2223dc389caa93b02770bdebb01ad67a',1,'RDTAPIs.h']]],
  ['rdt_5fset_5flog_5fpath',['RDT_Set_Log_Path',['../_r_d_t_a_p_is_8h.html#af4c60ef7acd591c68c19bc84ee8bc462',1,'RDTAPIs.h']]],
  ['rdt_5fset_5fmax_5fchannel_5fnumber',['RDT_Set_Max_Channel_Number',['../_r_d_t_a_p_is_8h.html#aa5509b42ceba82f7c382748da41bb4b8',1,'RDTAPIs.h']]],
  ['rdt_5fstatus_5fcheck',['RDT_Status_Check',['../_r_d_t_a_p_is_8h.html#a5965ee402c7e05d1a97113ddb70d4947',1,'RDTAPIs.h']]],
  ['rdt_5fwrite',['RDT_Write',['../_r_d_t_a_p_is_8h.html#acbd1e962928bf4d87fcbd0d70c9c408b',1,'RDTAPIs.h']]]
];
