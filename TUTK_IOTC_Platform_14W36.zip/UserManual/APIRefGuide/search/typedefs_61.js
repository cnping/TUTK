var searchData=
[
  ['authfn',['authFn',['../_a_v_a_p_is_8h.html#aa1e5cd6d6ffd8938e788da20ae5c20bc',1,'AVAPIs.h']]]
];
