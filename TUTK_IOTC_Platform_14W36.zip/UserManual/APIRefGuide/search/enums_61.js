var searchData=
[
  ['avioctrltype',['AVIOCtrlType',['../_a_v_a_p_is_8h.html#aa1aaee8df70d76b158c0206c1b1118ac',1,'AVAPIs.h']]]
];
