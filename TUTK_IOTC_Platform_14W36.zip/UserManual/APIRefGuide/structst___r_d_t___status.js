var structst___r_d_t___status =
[
    [ "BufSizeInRecvQueue", "structst___r_d_t___status.html#a77a2bd6dd9bd31245c083b4f426f4eba", null ],
    [ "BufSizeInSendQueue", "structst___r_d_t___status.html#a0f4127a69d47042b654e9bf5ba6719d0", null ],
    [ "Timeout", "structst___r_d_t___status.html#a790f3d2db6cf1f03bbd8232f6072915f", null ],
    [ "TimeoutThreshold", "structst___r_d_t___status.html#a511948fb282305a4fc345ff03bc50c28", null ]
];