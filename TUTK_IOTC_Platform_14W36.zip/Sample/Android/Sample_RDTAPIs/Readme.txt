1. Copy library from ../../../../Lib/Android/IOTCAPIs/libs/armeabi/libIOTCAPIs.so to ./libs/armeabi/
   Copy library from ../../../../Lib/Android/RDTAPIs/libs/armeabi/libRDTAPIs.so to ./libs/armeabi/
   Copy java file from ../../../../Lib/Android/IOTCAPIs/src/com/tutk/IOTC/*.java to ./src/com/tutk/IOTC/
   Copy java file from ../../../../Lib/Android/RDTAPIs/src/com/tutk/IOTC/*.java to ./src/com/tutk/IOTC/
2. Open project "Sample_RDTAPIs" and run it on mobile.
