1. Copy library from ../../../Lib/Android/P2PTunnelAPIs/libs/armeabi/libP2PTunnelAPIs.so to ./libs/armeabi/
   Copy java file from ../../../Lib/Android/P2PTunnelAPIs/src/com/tutk/IOTC/*.java to ./src/com/tutk/IOTC/
2. Open project "Sample_P2PTunnelAPIs" and run it on mobile.
