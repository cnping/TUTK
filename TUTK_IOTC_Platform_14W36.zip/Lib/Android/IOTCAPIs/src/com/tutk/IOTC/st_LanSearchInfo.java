package com.tutk.IOTC;

public class st_LanSearchInfo {
	public byte[] UID= null;
	public byte[] IP = null;
	public int port=0;
}
